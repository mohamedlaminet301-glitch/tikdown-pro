import { useEffect, useRef, useState } from 'react';
import type { StreamSource } from '../types';
import { extractQualities, pickSource } from '../services/api/videoService';

interface Props {
  sources: StreamSource[];
  title?: string;
  onProgress?: (seconds: number) => void;
  initialTime?: number;
  preferredQuality?: string;
}

export default function VideoPlayer({ sources, title, onProgress, initialTime = 0, preferredQuality }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [quality, setQuality] = useState(preferredQuality || '');
  const qualities = extractQualities(sources);
  const current = pickSource(sources, quality || preferredQuality);

  useEffect(() => {
    if (!quality && qualities.length) {
      setQuality(qualities[0]);
    }
  }, [qualities, quality]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v || !current?.url) return;
    const wasPlaying = !v.paused;
    const t = v.currentTime || initialTime;
    v.src = current.url;
    v.load();
    if (t > 0) v.currentTime = t;
    if (wasPlaying) v.play().catch(() => {});
  }, [current?.url]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v || !onProgress) return;
    const handler = () => onProgress(Math.floor(v.currentTime));
    v.addEventListener('timeupdate', handler);
    return () => v.removeEventListener('timeupdate', handler);
  }, [onProgress]);

  if (!sources.length || !current) {
    return (
      <div className="player-wrap" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
        Aucune source disponible
      </div>
    );
  }

  return (
    <div>
      <div className="player-wrap">
        <video
          ref={videoRef}
          controls
          playsInline
          preload="metadata"
          title={title}
        />
      </div>
      {qualities.length > 1 && (
        <div style={{ display: 'flex', gap: 6, padding: '8px 14px', overflowX: 'auto' }}>
          {qualities.map((q) => (
            <button
              key={q}
              type="button"
              className={`btn btn-sm${q === quality ? ' btn-primary' : ''}`}
              onClick={() => setQuality(q)}
            >
              {q}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
