import { memo } from 'react';
import { Link } from 'react-router-dom';
import type { AnimeItem } from '../types';

interface Props {
  item: AnimeItem;
}

function AnimeCard({ item }: Props) {
  const to = `/anime/${encodeURIComponent(item.slug)}?id=${item.subject_id}`;
  return (
    <Link to={to} className="card">
      {item.poster_url ? (
        <img
          className="card-poster"
          src={item.poster_url}
          alt=""
          loading="lazy"
          decoding="async"
          width={150}
          height={225}
        />
      ) : (
        <div className="card-poster skeleton" />
      )}
      <div className="card-body">
        <div className="card-title">{item.name}</div>
        {(item.rating || item.year) && (
          <div className="muted" style={{ marginTop: 2, fontSize: '0.7rem' }}>
            {item.year ? `${item.year}` : ''}
            {item.year && item.rating ? ' · ' : ''}
            {item.rating ? `★ ${item.rating}` : ''}
          </div>
        )}
      </div>
    </Link>
  );
}

export default memo(AnimeCard);
