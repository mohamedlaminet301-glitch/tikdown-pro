import { Link } from 'react-router-dom';

interface Props {
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
  right?: React.ReactNode;
}

export default function Header({ title, showBack, onBack, right }: Props) {
  return (
    <header className="app-header">
      {showBack ? (
        <button type="button" onClick={onBack || (() => history.back())} aria-label="Retour" style={{ fontSize: '1.2rem', padding: '4px 8px' }}>
          ←
        </button>
      ) : (
        <Link to="/" className="logo">
          Oni<span>.kage</span>
        </Link>
      )}
      {title && <span style={{ flex: 1, fontWeight: 600, fontSize: '1rem' }}>{title}</span>}
      {!title && <div style={{ flex: 1 }} />}
      {right}
    </header>
  );
}
