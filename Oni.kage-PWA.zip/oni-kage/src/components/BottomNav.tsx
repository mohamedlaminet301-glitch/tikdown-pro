import { NavLink } from 'react-router-dom';

const items = [
  { to: '/', label: 'Accueil', icon: '⌂' },
  { to: '/search', label: 'Recherche', icon: '⌕' },
  { to: '/downloads', label: 'Téléch.', icon: '↓' },
  { to: '/favorites', label: 'Favoris', icon: '♥' },
];

export default function BottomNav() {
  return (
    <nav className="bottom-nav">
      {items.map((it) => (
        <NavLink
          key={it.to}
          to={it.to}
          end={it.to === '/'}
          className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}
        >
          <span className="nav-icon">{it.icon}</span>
          <span>{it.label}</span>
        </NavLink>
      ))}
    </nav>
  );
}
