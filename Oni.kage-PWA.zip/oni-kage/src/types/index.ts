export interface AnimeItem {
  name: string;
  poster_url?: string;
  slug: string;
  subject_id: string | number;
  badge?: string;
  rating?: string | number;
  year?: string;
}

export interface Section {
  section: string;
  count: number;
  items: AnimeItem[];
}

export interface HomeResponse {
  status: string;
  sections: Section[];
}

export interface SearchResponse {
  query: string;
  page: number;
  total: number;
  items: AnimeItem[];
}

export interface StreamSource {
  resolution: string;
  format: string;
  url: string;
  size?: number;
  duration?: number;
  codec?: string;
}

export interface StreamResponse {
  subject_id: string;
  se: number;
  ep: number;
  has_resource: boolean;
  sources: StreamSource[];
  hls?: any[];
  dash?: any[];
  free_episodes?: number;
  limited?: boolean;
  note?: string | null;
}

export interface DetailData {
  [key: string]: any;
}

export interface FavoriteItem extends AnimeItem {
  addedAt: number;
}

export interface HistoryItem extends AnimeItem {
  lastEpisode: number;
  lastSeason: number;
  progress?: number;
  watchedAt: number;
}

export interface DownloadItem {
  id: string;
  subject_id: string;
  detail_path: string;
  title: string;
  episode: number;
  season: number;
  quality: string;
  url: string;
  status: 'pending' | 'downloading' | 'paused' | 'completed' | 'error';
  progress: number;
  size?: number;
  localPath?: string;
  createdAt: number;
}
