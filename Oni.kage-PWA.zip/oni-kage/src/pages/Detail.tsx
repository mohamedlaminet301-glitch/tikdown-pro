import { useEffect, useState } from 'react';
import { useParams, useSearchParams, Link } from 'react-router-dom';
import Header from '../components/Header';
import { getDetail } from '../services/api/animeService';
import { extractEpisodes } from '../services/api/episodeService';
import { isFavorite, toggleFavorite } from '../services/storage/favorites';
import type { DetailData, AnimeItem } from '../types';

export default function Detail() {
  const { slug = '' } = useParams();
  const [search] = useSearchParams();
  const subjectId = search.get('id') || '';
  const [detail, setDetail] = useState<DetailData | null>(null);
  const [episodes, setEpisodes] = useState<Array<{ se: number; ep: number; title?: string }>>([]);
  const [loading, setLoading] = useState(true);
  const [fav, setFav] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        setLoading(true);
        const data = await getDetail(slug);
        if (cancelled) return;
        setDetail(data);
        setEpisodes(extractEpisodes(data));
        if (subjectId) setFav(await isFavorite(subjectId));
      } catch (e: any) {
        if (!cancelled) setError(e.message || 'Erreur');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [slug, subjectId]);

  const subject = detail?.data?.subject || detail?.subject || detail?.data || detail || {};
  const title = subject.title || subject.name || slug;
  const poster = subject.cover?.url || subject.poster || subject.image?.url || '';
  const desc = subject.description || subject.intro || subject.summary || '';
  const year = (subject.releaseDate || subject.year || '').toString().slice(0, 4);
  const statusRaw = subject.status || subject.corner || '';
  const genres: string[] = subject.genres || subject.genreList || subject.tags || [];
  const rating = subject.imdbRatingValue || subject.rating;

  const animeItem: AnimeItem = {
    name: title,
    poster_url: poster,
    slug,
    subject_id: subjectId || subject.subjectId || '',
    rating,
    year,
  };

  const onToggleFav = async () => {
    const next = await toggleFavorite(animeItem);
    setFav(next);
  };

  return (
    <div className="page">
      <Header showBack title={title} right={
        <button type="button" onClick={onToggleFav} style={{ fontSize: '1.3rem', color: fav ? 'var(--accent)' : 'var(--text-muted)' }}>
          {fav ? '♥' : '♡'}
        </button>
      } />
      <div className="container">
        {loading && <div className="skeleton" style={{ height: 200, marginTop: 12 }} />}
        {error && <p className="muted" style={{ padding: 20 }}>{error}</p>}
        {!loading && !error && (
          <>
            <div style={{ display: 'flex', gap: 14, marginTop: 12 }}>
              {poster && (
                <img
                  src={poster}
                  alt=""
                  style={{ width: 110, borderRadius: 8, objectFit: 'cover', aspectRatio: '2/3' }}
                  loading="lazy"
                />
              )}
              <div style={{ flex: 1 }}>
                <h1 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: 6 }}>{title}</h1>
                <div className="muted" style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 8 }}>
                  {year && <span>{year}</span>}
                  {statusRaw && <span>· {statusRaw}</span>}
                  {rating && <span>· ★ {rating}</span>}
                </div>
                {Array.isArray(genres) && genres.length > 0 && (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                    {(typeof genres[0] === 'string' ? genres : genres.map((g: any) => g.name || g)).slice(0, 6).map((g: string) => (
                      <span key={g} style={{ fontSize: '0.72rem', padding: '2px 7px', background: 'var(--bg-elevated)', borderRadius: 4, border: '1px solid var(--border)' }}>
                        {g}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {desc && (
              <p style={{ marginTop: 14, fontSize: '0.9rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>
                {desc.slice(0, 500)}{desc.length > 500 ? '…' : ''}
              </p>
            )}

            <h2 className="section-title">Épisodes ({episodes.length || '—'})</h2>
            {episodes.length === 0 && (
              <p className="muted">Liste d'épisodes non disponible. Essayez de lancer la lecture.</p>
            )}
            <div className="ep-list">
              {(episodes.length ? episodes : [{ se: 0, ep: 1 }]).slice(0, 60).map((ep) => (
                <div key={`${ep.se}-${ep.ep}`} className="ep-row">
                  <span className="ep-num">E{ep.ep}</span>
                  <span className="muted" style={{ fontSize: '0.85rem' }}>
                    {ep.title || `Épisode ${ep.ep}`}
                    {ep.se > 0 ? ` · S${ep.se}` : ''}
                  </span>
                  <div className="ep-actions">
                    <Link
                      to={`/watch/${encodeURIComponent(slug)}?id=${subjectId || animeItem.subject_id}&se=${ep.se}&ep=${ep.ep}`}
                      className="btn btn-sm btn-primary"
                    >
                      ▶
                    </Link>
                  </div>
                </div>
              ))}
            </div>
            {episodes.length > 60 && (
              <p className="muted" style={{ marginTop: 8 }}>… et {episodes.length - 60} de plus</p>
            )}
          </>
        )}
      </div>
    </div>
  );
}
