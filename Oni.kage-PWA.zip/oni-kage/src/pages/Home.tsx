import { useEffect, useState } from 'react';
import Header from '../components/Header';
import AnimeCard from '../components/AnimeCard';
import { getHome, getAnimation } from '../services/api/animeService';
import type { Section, AnimeItem } from '../types';

export default function Home() {
  const [sections, setSections] = useState<Section[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        setLoading(true);
        const [home, anim] = await Promise.all([
          getHome().catch(() => null),
          getAnimation(1).catch(() => null),
        ]);
        if (cancelled) return;

        const result: Section[] = [];
        if (anim?.items?.length) {
          result.push({ section: 'Animes populaires', count: anim.items.length, items: anim.items });
        }
        if (home?.sections) {
          for (const s of home.sections) {
            if (s.items?.length && !/movie|cinema/i.test(s.section)) {
              result.push(s);
            }
          }
        }
        if (!result.length && anim?.items) {
          result.push({ section: 'Animes', count: anim.items.length, items: anim.items });
        }
        setSections(result);
      } catch (e: any) {
        if (!cancelled) setError(e.message || 'Erreur de chargement');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  return (
    <div className="page">
      <Header />
      <div className="container">
        {loading && (
          <div className="grid" style={{ marginTop: 16 }}>
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="card">
                <div className="card-poster skeleton" />
                <div className="card-body"><div className="skeleton" style={{ height: 14, width: '80%' }} /></div>
              </div>
            ))}
          </div>
        )}
        {error && (
          <p className="muted" style={{ padding: 24, textAlign: 'center' }}>
            {error}<br />
            <small>Vérifiez que l'API MovieBox tourne (VITE_API_BASE)</small>
          </p>
        )}
        {!loading && !error && sections.map((sec) => (
          <section key={sec.section}>
            <h2 className="section-title">{sec.section}</h2>
            <div className="grid">
              {sec.items.slice(0, 18).map((item: AnimeItem) => (
                <AnimeCard key={`${item.subject_id}-${item.slug}`} item={item} />
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
