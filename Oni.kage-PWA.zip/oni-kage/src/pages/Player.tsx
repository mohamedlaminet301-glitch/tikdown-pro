import { useEffect, useState, useCallback } from 'react';
import { useParams, useSearchParams, Link } from 'react-router-dom';
import Header from '../components/Header';
import VideoPlayer from '../components/VideoPlayer';
import { getStreamSources } from '../services/api/videoService';
import { requestDownload } from '../services/download/DownloadManager';
import { addToHistory, getLastPosition } from '../services/storage/history';
import type { StreamSource, AnimeItem } from '../types';

export default function Player() {
  const { slug = '' } = useParams();
  const [params] = useSearchParams();
  const subjectId = params.get('id') || '';
  const se = Number(params.get('se') || 0);
  const ep = Number(params.get('ep') || 1);

  const [sources, setSources] = useState<StreamSource[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [initialTime, setInitialTime] = useState(0);
  const [title, setTitle] = useState(`Épisode ${ep}`);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        setLoading(true);
        const [stream, last] = await Promise.all([
          getStreamSources(subjectId, slug, se, ep),
          getLastPosition(subjectId),
        ]);
        if (cancelled) return;
        setSources(stream.sources || []);
        if (!stream.has_resource && !(stream.sources?.length)) {
          setError(stream.note || 'Aucun flux trouvé');
        }
        if (last && last.se === se && last.ep === ep && last.progress > 10) {
          setInitialTime(last.progress);
        }
        setTitle(`S${se || 1} · E${ep}`);
      } catch (e: any) {
        if (!cancelled) setError(e.message || 'Erreur stream');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [subjectId, slug, se, ep]);

  const onProgress = useCallback(
    (seconds: number) => {
      if (!subjectId) return;
      const item: AnimeItem = {
        name: title,
        slug,
        subject_id: subjectId,
      };
      // Throttle writes roughly every 15s via simple check
      if (seconds % 15 < 2) {
        addToHistory(item, se, ep, seconds);
      }
    },
    [subjectId, slug, se, ep, title]
  );

  const onDownload = async () => {
    const best = sources[0];
    if (!best?.url) return;
    await requestDownload({
      subject_id: subjectId,
      detail_path: slug,
      title: title,
      episode: ep,
      season: se,
      quality: best.resolution || 'HD',
      url: best.url,
    });
    alert('Téléchargement lancé (navigateur)');
  };

  return (
    <div className="page" style={{ paddingBottom: 20 }}>
      <Header showBack title={title} right={
        sources.length > 0 ? (
          <button type="button" className="btn btn-sm" onClick={onDownload}>⬇</button>
        ) : null
      } />
      {loading && <div className="skeleton" style={{ aspectRatio: '16/9' }} />}
      {error && (
        <p className="muted" style={{ padding: 24, textAlign: 'center' }}>{error}</p>
      )}
      {!loading && !error && (
        <VideoPlayer
          sources={sources}
          title={title}
          onProgress={onProgress}
          initialTime={initialTime}
        />
      )}
      <div className="container" style={{ marginTop: 12 }}>
        <Link to={`/anime/${encodeURIComponent(slug)}?id=${subjectId}`} className="btn btn-sm">
          ← Fiche anime
        </Link>
      </div>
    </div>
  );
}
