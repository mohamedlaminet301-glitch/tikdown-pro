import { useState, useEffect, useRef } from 'react';
import Header from '../components/Header';
import AnimeCard from '../components/AnimeCard';
import { searchAnime } from '../services/api/animeService';
import type { AnimeItem } from '../types';

export default function Search() {
  const [q, setQ] = useState('');
  const [items, setItems] = useState<AnimeItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const timer = useRef<number>();

  useEffect(() => {
    if (!q.trim()) {
      setItems([]);
      setSearched(false);
      return;
    }
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(async () => {
      setLoading(true);
      setSearched(true);
      try {
        const res = await searchAnime(q.trim());
        setItems(res.items || []);
      } catch {
        setItems([]);
      } finally {
        setLoading(false);
      }
    }, 320);
    return () => window.clearTimeout(timer.current);
  }, [q]);

  return (
    <div className="page">
      <Header title="Recherche" />
      <div className="container" style={{ paddingTop: 12 }}>
        <input
          type="search"
          placeholder="Rechercher un anime…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          autoFocus
          autoComplete="off"
        />
        {loading && <p className="muted" style={{ marginTop: 16 }}>Recherche…</p>}
        {!loading && searched && items.length === 0 && (
          <p className="muted" style={{ marginTop: 16, textAlign: 'center' }}>Aucun résultat</p>
        )}
        <div className="grid" style={{ marginTop: 16 }}>
          {items.map((item) => (
            <AnimeCard key={`${item.subject_id}-${item.slug}`} item={item} />
          ))}
        </div>
      </div>
    </div>
  );
}
