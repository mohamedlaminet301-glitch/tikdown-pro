import { useEffect, useState } from 'react';
import Header from '../components/Header';
import { listDownloads, cancelDownload } from '../services/download/DownloadManager';
import type { DownloadItem } from '../types';

export default function Downloads() {
  const [items, setItems] = useState<DownloadItem[]>([]);

  const refresh = () => listDownloads().then(setItems);
  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 2000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="page">
      <Header title="Téléchargements" />
      <div className="container">
        {items.length === 0 ? (
          <p className="muted" style={{ textAlign: 'center', marginTop: 40 }}>
            Aucun téléchargement.<br />
            <small>Le système est prêt pour Capacitor (arrière-plan, notifications).</small>
          </p>
        ) : (
          <div className="ep-list" style={{ marginTop: 12 }}>
            {items.map((d) => (
              <div key={d.id} className="ep-row">
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 500, fontSize: '0.9rem' }}>{d.title}</div>
                  <div className="muted" style={{ fontSize: '0.75rem' }}>
                    S{d.season}E{d.episode} · {d.quality} · {d.status} {d.progress > 0 ? `${d.progress}%` : ''}
                  </div>
                </div>
                <button type="button" className="btn btn-sm" onClick={() => cancelDownload(d.id).then(refresh)}>
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
