import { useEffect, useState } from 'react';
import Header from '../components/Header';
import AnimeCard from '../components/AnimeCard';
import { getFavorites } from '../services/storage/favorites';
import type { FavoriteItem } from '../types';

export default function Favorites() {
  const [items, setItems] = useState<FavoriteItem[]>([]);

  useEffect(() => {
    getFavorites().then(setItems);
  }, []);

  return (
    <div className="page">
      <Header title="Favoris" />
      <div className="container">
        {items.length === 0 ? (
          <p className="muted" style={{ textAlign: 'center', marginTop: 40 }}>
            Aucun favori pour le moment.
          </p>
        ) : (
          <div className="grid" style={{ marginTop: 12 }}>
            {items.map((item) => (
              <AnimeCard key={String(item.subject_id)} item={item} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
