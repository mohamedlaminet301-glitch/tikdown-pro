/**
 * Notification abstraction.
 * PWA: Notification API when permission granted.
 * Capacitor: @capacitor/local-notifications later.
 */
export interface INotificationService {
  requestPermission(): Promise<boolean>;
  show(title: string, body?: string, options?: NotificationOptions): Promise<void>;
}

class BrowserNotificationService implements INotificationService {
  async requestPermission(): Promise<boolean> {
    if (!('Notification' in window)) return false;
    if (Notification.permission === 'granted') return true;
    if (Notification.permission === 'denied') return false;
    const result = await Notification.requestPermission();
    return result === 'granted';
  }

  async show(title: string, body?: string, options?: NotificationOptions): Promise<void> {
    if (Notification.permission !== 'granted') return;
    new Notification(title, { body, icon: '/icons/icon-192.png', ...options });
  }
}

export const notificationService: INotificationService = new BrowserNotificationService();
