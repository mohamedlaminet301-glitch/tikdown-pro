import { apiGet } from './client';
import type { StreamResponse, StreamSource } from '../../types';

/**
 * Fetch available stream sources for a subject/episode.
 * Only qualities returned by the API are exposed – never invent missing ones.
 */
export async function getStreamSources(
  subjectId: string | number,
  detailPath: string,
  se = 0,
  ep = 0
): Promise<StreamResponse> {
  return apiGet<StreamResponse>(`/api/stream/${subjectId}`, {
    detail_path: detailPath,
    se,
    ep,
  });
}

/**
 * Return sorted unique resolutions that actually exist.
 */
export function extractQualities(sources: StreamSource[]): string[] {
  const set = new Set<string>();
  for (const s of sources) {
    if (s.resolution && s.url) set.add(s.resolution);
  }
  // Prefer higher first
  return Array.from(set).sort((a, b) => {
    const na = parseInt(a) || 0;
    const nb = parseInt(b) || 0;
    return nb - na;
  });
}

/**
 * Pick best or requested quality URL.
 */
export function pickSource(sources: StreamSource[], preferred?: string): StreamSource | null {
  if (!sources.length) return null;
  if (preferred) {
    const match = sources.find((s) => s.resolution === preferred && s.url);
    if (match) return match;
  }
  // highest available
  const sorted = [...sources].sort((a, b) => {
    const na = parseInt(a.resolution) || 0;
    const nb = parseInt(b.resolution) || 0;
    return nb - na;
  });
  return sorted.find((s) => s.url) || null;
}
