import { getDetail } from './animeService';
import type { DetailData } from '../../types';

/**
 * Extract episode list from detail payload.
 * MovieBox detail structure varies; we normalize common shapes.
 */
export function extractEpisodes(detail: DetailData): Array<{
  se: number;
  ep: number;
  title?: string;
  free?: boolean;
}> {
  const list: Array<{ se: number; ep: number; title?: string; free?: boolean }> = [];

  // Common paths observed in MovieBox-like payloads
  const subjects = detail?.data?.subject || detail?.subject || detail?.data || detail;

  // Try seasons / episodeList / resourceList
  const seasons = subjects?.seasons || subjects?.seasonList || subjects?.resource?.seasons || [];
  if (Array.isArray(seasons) && seasons.length) {
    for (const season of seasons) {
      const seNum = season.season || season.se || season.number || 1;
      const eps = season.episodes || season.episodeList || season.list || [];
      if (Array.isArray(eps)) {
        for (const ep of eps) {
          list.push({
            se: Number(seNum),
            ep: Number(ep.episode || ep.ep || ep.number || ep),
            title: ep.title || ep.name,
            free: ep.free ?? true,
          });
        }
      }
    }
  }

  // Fallback: total episodes count → generate 1..N for se=0 or 1
  if (list.length === 0) {
    const total =
      subjects?.episodeCount ||
      subjects?.totalEpisodes ||
      subjects?.resource?.episodeCount ||
      subjects?.eps ||
      0;
    const se = subjects?.seasonCount > 1 ? 1 : 0;
    for (let i = 1; i <= Number(total) || 0; i++) {
      list.push({ se, ep: i });
    }
  }

  // Deduplicate & sort
  const map = new Map<string, typeof list[0]>();
  for (const e of list) {
    map.set(`${e.se}-${e.ep}`, e);
  }
  return Array.from(map.values()).sort((a, b) => a.se - b.se || a.ep - b.ep);
}

export async function getEpisodes(slug: string) {
  const detail = await getDetail(slug);
  return { detail, episodes: extractEpisodes(detail) };
}
