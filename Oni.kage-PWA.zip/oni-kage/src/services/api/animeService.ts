import { apiGet } from './client';
import type { HomeResponse, SearchResponse, AnimeItem, DetailData } from '../../types';

/** Home page sections (banners + categories). Prefer animation-related. */
export async function getHome(): Promise<HomeResponse> {
  return apiGet<HomeResponse>('/home');
}

/** Dedicated animation / anime catalog. */
export async function getAnimation(page = 1, sort = 'RECOMMEND'): Promise<{
  page: number;
  per_page: number;
  total: number;
  items: AnimeItem[];
}> {
  return apiGet('/animation', { page, sort });
}

/** Search animes / titles. */
export async function searchAnime(q: string, page = 1): Promise<SearchResponse> {
  return apiGet<SearchResponse>('/search', { q, page });
}

/** Search suggestions (autocomplete). */
export async function getSuggestions(q: string): Promise<{ suggestions: Array<{ title: string; slug?: string; subject_id?: string }> }> {
  return apiGet('/search/suggest', { q });
}

/** Full detail by slug (detailPath). */
export async function getDetail(slug: string): Promise<DetailData> {
  return apiGet(`/detail/${encodeURIComponent(slug)}`);
}
