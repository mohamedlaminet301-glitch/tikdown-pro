import { storage } from './StorageService';
import type { HistoryItem, AnimeItem } from '../../types';

const KEY = 'oni.history';

export async function getHistory(): Promise<HistoryItem[]> {
  return (await storage.get<HistoryItem[]>(KEY)) || [];
}

export async function addToHistory(
  item: AnimeItem,
  se: number,
  ep: number,
  progress = 0
): Promise<void> {
  const list = await getHistory();
  const idx = list.findIndex((h) => String(h.subject_id) === String(item.subject_id));
  const entry: HistoryItem = {
    ...item,
    lastSeason: se,
    lastEpisode: ep,
    progress,
    watchedAt: Date.now(),
  };
  if (idx >= 0) list.splice(idx, 1);
  list.unshift(entry);
  if (list.length > 100) list.length = 100;
  await storage.set(KEY, list);
}

export async function getLastPosition(subjectId: string | number): Promise<{ se: number; ep: number; progress: number } | null> {
  const list = await getHistory();
  const h = list.find((x) => String(x.subject_id) === String(subjectId));
  if (!h) return null;
  return { se: h.lastSeason, ep: h.lastEpisode, progress: h.progress || 0 };
}
