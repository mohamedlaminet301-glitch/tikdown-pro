/**
 * Abstract storage layer.
 * Today: localStorage (PWA).
 * Tomorrow: Capacitor Preferences / SQLite without changing callers.
 */
export interface IStorage {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T): Promise<void>;
  remove(key: string): Promise<void>;
  keys(): Promise<string[]>;
}

class LocalStorageService implements IStorage {
  async get<T>(key: string): Promise<T | null> {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : null;
    } catch {
      return null;
    }
  }

  async set<T>(key: string, value: T): Promise<void> {
    localStorage.setItem(key, JSON.stringify(value));
  }

  async remove(key: string): Promise<void> {
    localStorage.removeItem(key);
  }

  async keys(): Promise<string[]> {
    return Object.keys(localStorage);
  }
}

// Singleton – swap implementation here for Capacitor later
export const storage: IStorage = new LocalStorageService();
