import { storage } from './StorageService';
import type { FavoriteItem, AnimeItem } from '../../types';

const KEY = 'oni.favorites';

export async function getFavorites(): Promise<FavoriteItem[]> {
  return (await storage.get<FavoriteItem[]>(KEY)) || [];
}

export async function isFavorite(subjectId: string | number): Promise<boolean> {
  const list = await getFavorites();
  return list.some((f) => String(f.subject_id) === String(subjectId));
}

export async function toggleFavorite(item: AnimeItem): Promise<boolean> {
  const list = await getFavorites();
  const idx = list.findIndex((f) => String(f.subject_id) === String(item.subject_id));
  if (idx >= 0) {
    list.splice(idx, 1);
    await storage.set(KEY, list);
    return false;
  }
  list.unshift({ ...item, addedAt: Date.now() });
  // keep reasonable size
  if (list.length > 200) list.length = 200;
  await storage.set(KEY, list);
  return true;
}
