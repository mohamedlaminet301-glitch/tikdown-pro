/**
 * Abstract download service.
 * PWA today: browser download / Cache API placeholder.
 * Capacitor tomorrow: Filesystem + BackgroundFetch + Notifications.
 */
import type { DownloadItem } from '../../types';

export interface IDownloadService {
  enqueue(item: Omit<DownloadItem, 'id' | 'status' | 'progress' | 'createdAt'>): Promise<string>;
  getAll(): Promise<DownloadItem[]>;
  pause(id: string): Promise<void>;
  resume(id: string): Promise<void>;
  cancel(id: string): Promise<void>;
  getProgress(id: string): Promise<number>;
}

/**
 * Current PWA implementation – opens the stream URL so the browser
 * can handle the download. Real background downloads require Capacitor.
 */
class BrowserDownloadService implements IDownloadService {
  private items: Map<string, DownloadItem> = new Map();
  private storageKey = 'oni.downloads';

  constructor() {
    this.load();
  }

  private async load() {
    try {
      const raw = localStorage.getItem(this.storageKey);
      if (raw) {
        const arr: DownloadItem[] = JSON.parse(raw);
        arr.forEach((i) => this.items.set(i.id, i));
      }
    } catch {}
  }

  private persist() {
    localStorage.setItem(this.storageKey, JSON.stringify(Array.from(this.items.values())));
  }

  async enqueue(partial: Omit<DownloadItem, 'id' | 'status' | 'progress' | 'createdAt'>): Promise<string> {
    const id = `${partial.subject_id}-${partial.season}-${partial.episode}-${Date.now()}`;
    const item: DownloadItem = {
      ...partial,
      id,
      status: 'pending',
      progress: 0,
      createdAt: Date.now(),
    };
    this.items.set(id, item);
    this.persist();

    // Trigger browser download (user must confirm)
    try {
      const a = document.createElement('a');
      a.href = partial.url;
      a.download = `${partial.title}_S${partial.season}E${partial.episode}_${partial.quality}.mp4`;
      a.target = '_blank';
      a.rel = 'noopener';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      item.status = 'downloading';
      item.progress = 10;
      this.persist();
      // We cannot track real progress without a proxy or Capacitor
      setTimeout(() => {
        item.status = 'completed';
        item.progress = 100;
        this.persist();
      }, 2000);
    } catch {
      item.status = 'error';
      this.persist();
    }
    return id;
  }

  async getAll(): Promise<DownloadItem[]> {
    return Array.from(this.items.values()).sort((a, b) => b.createdAt - a.createdAt);
  }

  async pause(id: string): Promise<void> {
    const item = this.items.get(id);
    if (item && item.status === 'downloading') {
      item.status = 'paused';
      this.persist();
    }
  }

  async resume(id: string): Promise<void> {
    const item = this.items.get(id);
    if (item && item.status === 'paused') {
      item.status = 'downloading';
      this.persist();
    }
  }

  async cancel(id: string): Promise<void> {
    this.items.delete(id);
    this.persist();
  }

  async getProgress(id: string): Promise<number> {
    return this.items.get(id)?.progress ?? 0;
  }
}

export const downloadService: IDownloadService = new BrowserDownloadService();
