/**
 * Download Manager – single entry point used by UI.
 * Keeps buttons dumb; all logic lives here.
 * Future Capacitor features (background, notifications, filesystem)
 * will be plugged into DownloadService without touching UI.
 */
import { downloadService } from './DownloadService';
import type { DownloadItem } from '../../types';

export async function requestDownload(params: {
  subject_id: string | number;
  detail_path: string;
  title: string;
  episode: number;
  season: number;
  quality: string;
  url: string;
}): Promise<string> {
  return downloadService.enqueue({
    subject_id: String(params.subject_id),
    detail_path: params.detail_path,
    title: params.title,
    episode: params.episode,
    season: params.season,
    quality: params.quality,
    url: params.url,
  });
}

export async function listDownloads(): Promise<DownloadItem[]> {
  return downloadService.getAll();
}

export async function pauseDownload(id: string) {
  return downloadService.pause(id);
}

export async function resumeDownload(id: string) {
  return downloadService.resume(id);
}

export async function cancelDownload(id: string) {
  return downloadService.cancel(id);
}
