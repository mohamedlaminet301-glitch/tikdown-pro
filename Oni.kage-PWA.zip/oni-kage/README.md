# Oni.kage

PWA de streaming d'animes – **priorité absolue à la fluidité**.

Design sombre, minimaliste, optimisé mobile. Aucun compte utilisateur. Données locales (favoris, historique, progression).

## Stack

- React 19 + Vite 6 + TypeScript
- React Router
- vite-plugin-pwa (manifest + service worker + cache)
- Aucune lib UI lourde

## Architecture

```
src/
  services/
    api/          # animeService, episodeService, videoService + client
    storage/      # StorageService (swap → Capacitor later)
    download/     # DownloadManager + DownloadService
    notification/ # NotificationService
  pages/          # Home, Search, Detail, Player, Favorites, Downloads
  components/     # AnimeCard, VideoPlayer, BottomNav, Header
```

L'API MovieBox est appelée uniquement via la couche `services/api`.  
Pour changer de backend plus tard, modifier uniquement ces fichiers.

## Configuration API

Créez un fichier `.env` :

```
VITE_API_BASE=http://localhost:8000
```

(ou l'URL de votre instance déployée de MovieBox-API)

L'API doit autoriser CORS (`allow_origins=["*"]` dans le code fourni).

## Lancement

```bash
cd oni-kage
npm install
npm run dev
```

Build production :

```bash
npm run build
npm run preview
```

## Fonctionnalités

- Accueil : sections animes (animation + home)
- Recherche debounced
- Fiche détail + liste d'épisodes
- Lecteur HTML5 + choix de qualités dynamiques (uniquement celles renvoyées par l'API)
- Favoris & historique (localStorage)
- Download Manager abstrait (prêt pour Capacitor)
- PWA installable, cache images + meta API

## Préparation Capacitor

Interfaces déjà présentes :

- `IStorage` → remplacer LocalStorageService
- `IDownloadService` → Filesystem + Background Tasks
- `INotificationService` → Local Notifications

Aucun changement de UI nécessaire.

## Identité

**Oni.kage** – univers anime, mystérieux, élégance sobre.  
Couleur d'accent : violet doux (`#c084fc`). Fond quasi-noir. Navigation basique 4 onglets.
