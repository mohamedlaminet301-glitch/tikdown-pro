import { Outlet, NavLink, useLocation } from 'react-router-dom';
import { Home, Library, Download, Settings, Shield, User } from 'lucide-react';
import { useStore } from '../store/useStore';
import clsx from 'clsx';

const nav = [
  { to: '/', icon: Home, label: 'Accueil' },
  { to: '/library', icon: Library, label: 'Bibliothèque' },
  { to: '/downloads', icon: Download, label: 'Téléchargements' },
  { to: '/settings', icon: Settings, label: 'Paramètres' }
];

export default function Layout() {
  const location = useLocation();
  const user = useStore((s) => s.user);
  const isAdmin = user?.role === 'admin';

  return (
    <div className="flex flex-col min-h-dvh max-w-lg mx-auto relative">
      {/* Top bar */}
      <header className="sticky top-0 z-40 glass-strong px-4 py-3 flex items-center justify-between safe-top">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center font-bold text-sm">
            TV
          </div>
          <span className="font-semibold tracking-tight">TikVault</span>
        </div>
        <NavLink
          to="/settings"
          className="w-9 h-9 rounded-full glass flex items-center justify-center"
        >
          {user?.avatar_url ? (
            <img src={user.avatar_url} alt="" className="w-full h-full rounded-full object-cover" />
          ) : (
            <User size={18} className="opacity-70" />
          )}
        </NavLink>
      </header>

      <main className="flex-1 px-4 pb-24 pt-2 overflow-y-auto">
        <Outlet />
      </main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 max-w-lg mx-auto">
        <div className="glass-strong mx-3 mb-3 rounded-2xl px-2 py-2 flex justify-around items-center shadow-2xl">
          {nav.map(({ to, icon: Icon, label }) => {
            const active = location.pathname === to;
            return (
              <NavLink
                key={to}
                to={to}
                className={clsx(
                  'flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-all duration-200',
                  active ? 'text-primary-light bg-white/10' : 'text-white/50 hover:text-white/80'
                )}
              >
                <Icon size={20} strokeWidth={active ? 2.5 : 2} />
                <span className="text-[10px] font-medium">{label}</span>
              </NavLink>
            );
          })}
          {isAdmin && (
            <NavLink
              to="/admin"
              className={clsx(
                'flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl',
                location.pathname === '/admin' ? 'text-primary-light bg-white/10' : 'text-white/50'
              )}
            >
              <Shield size={20} />
              <span className="text-[10px]">Admin</span>
            </NavLink>
          )}
        </div>
      </nav>
    </div>
  );
}
