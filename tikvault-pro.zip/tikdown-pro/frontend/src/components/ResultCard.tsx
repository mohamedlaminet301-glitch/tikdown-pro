import { Download, Music, Share2, ExternalLink } from 'lucide-react';
import type { AnalyzeResult } from '../types';
import { motion } from 'framer-motion';

interface Props {
  result: AnalyzeResult;
  onDownload: (source: AnalyzeResult['sources'][0]) => void;
}

export default function ResultCard({ result, onDownload }: Props) {
  const videoSources = result.sources.filter((s) => s.format === 'video');
  const audioSources = result.sources.filter((s) => s.format === 'audio');

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-3xl overflow-hidden"
    >
      {result.thumbnail && (
        <div className="relative aspect-[9/14] max-h-72 bg-surface-2">
          <img
            src={result.thumbnail}
            alt={result.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
          <div className="absolute bottom-3 left-3 right-3">
            <p className="text-xs uppercase tracking-wider text-primary-light mb-1">
              {result.platform} · {result.type}
            </p>
            <h3 className="font-semibold text-base line-clamp-2">{result.title}</h3>
            <p className="text-sm text-white/60 mt-0.5">@{result.author}</p>
          </div>
        </div>
      )}

      <div className="p-4 space-y-3">
        {!result.thumbnail && (
          <div>
            <p className="text-xs uppercase tracking-wider text-primary-light mb-1">
              {result.platform} · {result.type}
            </p>
            <h3 className="font-semibold">{result.title}</h3>
            <p className="text-sm text-white/60">@{result.author}</p>
          </div>
        )}

        <div className="flex flex-wrap gap-2">
          {videoSources.slice(0, 2).map((s) => (
            <button
              key={s.index}
              onClick={() => onDownload(s)}
              className="flex-1 min-w-[120px] flex items-center justify-center gap-2 rounded-xl bg-primary/20 hover:bg-primary/30 border border-primary/30 py-2.5 text-sm font-medium transition"
            >
              <Download size={16} />
              Vidéo {s.quality === 'hd' ? 'HD' : ''}
            </button>
          ))}
          {audioSources.length > 0 && (
            <button
              onClick={() => onDownload(audioSources[0])}
              className="flex-1 min-w-[120px] flex items-center justify-center gap-2 rounded-xl bg-accent/20 hover:bg-accent/30 border border-accent/30 py-2.5 text-sm font-medium transition"
            >
              <Music size={16} />
              Audio
            </button>
          )}
        </div>

        <div className="flex gap-2">
          <a
            href={result.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 flex items-center justify-center gap-2 rounded-xl glass py-2 text-sm text-white/70 hover:text-white transition"
          >
            <ExternalLink size={14} />
            Original
          </a>
          <button
            onClick={() => {
              if (navigator.share) {
                navigator.share({ title: result.title, url: result.url });
              } else {
                navigator.clipboard.writeText(result.url);
              }
            }}
            className="flex-1 flex items-center justify-center gap-2 rounded-xl glass py-2 text-sm text-white/70 hover:text-white transition"
          >
            <Share2 size={14} />
            Partager
          </button>
        </div>
      </div>
    </motion.div>
  );
}
