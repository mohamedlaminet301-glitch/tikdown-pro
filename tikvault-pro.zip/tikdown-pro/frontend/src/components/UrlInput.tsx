import { useState } from 'react';
import { Link2, Loader2, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

interface Props {
  onAnalyze: (url: string) => void;
  loading?: boolean;
}

export default function UrlInput({ onAnalyze, loading }: Props) {
  const [url, setUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = url.trim();
    if (trimmed) onAnalyze(trimmed);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <div className="relative">
        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40">
          <Link2 size={20} />
        </div>
        <input
          type="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Collez un lien TikTok..."
          className="w-full glass rounded-2xl pl-12 pr-4 py-4 text-sm placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-primary/50 transition"
          disabled={loading}
        />
      </div>
      <motion.button
        type="submit"
        disabled={loading || !url.trim()}
        whileTap={{ scale: 0.97 }}
        className="w-full rounded-2xl bg-gradient-to-r from-primary to-accent py-3.5 font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shadow-primary/25"
      >
        {loading ? (
          <>
            <Loader2 size={18} className="animate-spin" />
            Analyse en cours...
          </>
        ) : (
          <>
            <Sparkles size={18} />
            Analyser
          </>
        )}
      </motion.button>
    </form>
  );
}
