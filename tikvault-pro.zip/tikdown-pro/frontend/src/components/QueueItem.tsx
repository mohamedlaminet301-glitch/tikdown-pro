import { Pause, Play, X, CheckCircle2 } from 'lucide-react';
import type { DownloadItem } from '../types';
import clsx from 'clsx';

interface Props {
  item: DownloadItem;
  onPause?: () => void;
  onResume?: () => void;
  onCancel?: () => void;
}

export default function QueueItem({ item, onPause, onResume, onCancel }: Props) {
  const pct = Math.round(item.progress || 0);
  const isDone = item.status === 'completed';
  const isPaused = item.status === 'paused';
  const isActive = item.status === 'downloading';

  return (
    <div className="glass rounded-2xl p-3 flex gap-3 items-center">
      {item.thumbnail ? (
        <img src={item.thumbnail} alt="" className="w-12 h-12 rounded-xl object-cover flex-shrink-0" />
      ) : (
        <div className="w-12 h-12 rounded-xl bg-surface-3 flex-shrink-0" />
      )}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium truncate">{item.title}</p>
        <div className="mt-1.5 h-1.5 rounded-full bg-white/10 overflow-hidden">
          <div
            className={clsx(
              'h-full rounded-full transition-all duration-300',
              isDone ? 'bg-success' : isActive ? 'bg-primary progress-active' : 'bg-white/30'
            )}
            style={{ width: `${pct}%` }}
          />
        </div>
        <p className="text-[11px] text-white/50 mt-1">
          {isDone ? 'Terminé' : isPaused ? 'En pause' : isActive ? `${pct}%` : item.status}
        </p>
      </div>
      <div className="flex gap-1">
        {isActive && onPause && (
          <button onClick={onPause} className="p-2 rounded-lg hover:bg-white/10">
            <Pause size={16} />
          </button>
        )}
        {isPaused && onResume && (
          <button onClick={onResume} className="p-2 rounded-lg hover:bg-white/10">
            <Play size={16} />
          </button>
        )}
        {isDone ? (
          <CheckCircle2 size={18} className="text-success m-2" />
        ) : (
          onCancel && (
            <button onClick={onCancel} className="p-2 rounded-lg hover:bg-white/10 text-white/50">
              <X size={16} />
            </button>
          )
        )}
      </div>
    </div>
  );
}
