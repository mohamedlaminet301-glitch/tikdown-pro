import { useEffect } from 'react';
import QueueItem from '../components/QueueItem';
import { getQueue, updateDownload } from '../lib/api';
import { useStore } from '../store/useStore';
import { Link } from 'react-router-dom';

export default function Downloads() {
  const { user, queue, setQueue, updateDownloadProgress } = useStore();

  useEffect(() => {
    if (!user) return;
    getQueue()
      .then((data) => {
        // map queue rows to DownloadItem-like
        setQueue(
          data.map((q: any) => ({
            id: q.download_id || q.id,
            title: q.title,
            progress: q.progress || 0,
            status: q.download_status || q.status,
            thumbnail: q.thumbnail
          }))
        );
      })
      .catch(() => {});
  }, [user]);

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
        <p className="text-white/60">Connectez-vous pour gérer vos téléchargements</p>
        <Link to="/settings" className="text-primary-light text-sm font-medium">
          Aller aux paramètres →
        </Link>
      </div>
    );
  }

  const handlePause = async (id: string) => {
    await updateDownload(id, { status: 'paused' });
    updateDownloadProgress(id, 0, 'paused');
  };

  const handleResume = async (id: string) => {
    await updateDownload(id, { status: 'downloading' });
    updateDownloadProgress(id, 50, 'downloading');
  };

  const handleCancel = async (id: string) => {
    await updateDownload(id, { status: 'cancelled' });
    setQueue(queue.filter((q) => q.id !== id));
  };

  return (
    <div className="space-y-4 pt-2">
      <h1 className="text-xl font-bold">Gestionnaire</h1>
      <p className="text-sm text-white/50">File d'attente et progression</p>

      {queue.length === 0 ? (
        <div className="glass rounded-3xl p-8 text-center text-white/40 text-sm">
          Aucun téléchargement en cours
        </div>
      ) : (
        <div className="space-y-2">
          {queue.map((item) => (
            <QueueItem
              key={item.id}
              item={item as any}
              onPause={() => handlePause(item.id)}
              onResume={() => handleResume(item.id)}
              onCancel={() => handleCancel(item.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
