import { useState } from 'react';
import { LogIn, LogOut, User, Globe, Download, Bell, Wifi } from 'lucide-react';
import { login, register, updateMe } from '../lib/api';
import { useStore } from '../store/useStore';

export default function Settings() {
  const { user, setAuth, logout } = useStore();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const prefs = (user?.preferences || {}) as Record<string, any>;

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const data =
        mode === 'login'
          ? await login(email, password)
          : await register(email, password, username || undefined);
      setAuth(data.user, data.token);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Erreur');
    } finally {
      setLoading(false);
    }
  };

  const updatePref = async (key: string, value: unknown) => {
    if (!user) return;
    const next = { ...prefs, [key]: value };
    const updated = await updateMe({ preferences: next });
    setAuth(updated, useStore.getState().token);
  };

  return (
    <div className="space-y-6 pt-2">
      <h1 className="text-xl font-bold">Paramètres</h1>

      {!user ? (
        <div className="glass rounded-3xl p-5 space-y-4">
          <div className="flex gap-2 mb-2">
            <button
              onClick={() => setMode('login')}
              className={`flex-1 py-2 rounded-xl text-sm font-medium ${
                mode === 'login' ? 'bg-primary/30 text-primary-light' : 'text-white/50'
              }`}
            >
              Connexion
            </button>
            <button
              onClick={() => setMode('register')}
              className={`flex-1 py-2 rounded-xl text-sm font-medium ${
                mode === 'register' ? 'bg-primary/30 text-primary-light' : 'text-white/50'
              }`}
            >
              Inscription
            </button>
          </div>
          <form onSubmit={handleAuth} className="space-y-3">
            {mode === 'register' && (
              <input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Pseudo"
                className="w-full glass rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
            )}
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              required
              className="w-full glass rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Mot de passe"
              required
              minLength={6}
              className="w-full glass rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
            {error && <p className="text-sm text-danger">{error}</p>}
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-gradient-to-r from-primary to-accent py-3 text-sm font-semibold disabled:opacity-50"
            >
              {loading ? '...' : mode === 'login' ? 'Se connecter' : "S'inscrire"}
            </button>
          </form>
          <p className="text-[11px] text-white/40 text-center">
            Google OAuth : structure prête (à configurer côté serveur)
          </p>
        </div>
      ) : (
        <>
          <div className="glass rounded-3xl p-5 flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-xl font-bold">
              {user.username?.[0]?.toUpperCase() || 'U'}
            </div>
            <div className="flex-1">
              <p className="font-semibold">{user.username}</p>
              <p className="text-sm text-white/50">{user.email}</p>
            </div>
            <button onClick={logout} className="p-2 rounded-xl hover:bg-white/10 text-white/60">
              <LogOut size={18} />
            </button>
          </div>

          <section className="space-y-2">
            <h2 className="text-sm font-semibold text-white/50 flex items-center gap-2">
              <Download size={14} /> Téléchargement
            </h2>
            <div className="glass rounded-2xl divide-y divide-white/5">
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-sm">Qualité par défaut</span>
                <select
                  value={prefs.quality || 'hd'}
                  onChange={(e) => updatePref('quality', e.target.value)}
                  className="bg-transparent text-sm text-primary-light focus:outline-none"
                >
                  <option value="hd">HD</option>
                  <option value="standard">Standard</option>
                </select>
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-sm">Format préféré</span>
                <select
                  value={prefs.format || 'mp4'}
                  onChange={(e) => updatePref('format', e.target.value)}
                  className="bg-transparent text-sm text-primary-light focus:outline-none"
                >
                  <option value="mp4">MP4</option>
                  <option value="mp3">MP3</option>
                </select>
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-sm flex items-center gap-2">
                  <Wifi size={14} /> Wi-Fi uniquement
                </span>
                <button
                  onClick={() => updatePref('wifiOnly', !prefs.wifiOnly)}
                  className={`w-11 h-6 rounded-full transition ${
                    prefs.wifiOnly ? 'bg-primary' : 'bg-white/20'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white shadow transition transform ${
                      prefs.wifiOnly ? 'translate-x-5' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-sm flex items-center gap-2">
                  <Bell size={14} /> Notifications
                </span>
                <button
                  onClick={() => updatePref('notifications', !prefs.notifications)}
                  className={`w-11 h-6 rounded-full transition ${
                    prefs.notifications ? 'bg-primary' : 'bg-white/20'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white shadow transition transform ${
                      prefs.notifications ? 'translate-x-5' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>
            </div>
          </section>

          <section className="space-y-2">
            <h2 className="text-sm font-semibold text-white/50 flex items-center gap-2">
              <Globe size={14} /> Langue
            </h2>
            <div className="glass rounded-2xl px-4 py-3 flex justify-between items-center">
              <span className="text-sm">Français</span>
              <span className="text-xs text-white/40">Bientôt d'autres langues</span>
            </div>
          </section>
        </>
      )}
    </div>
  );
}
