import { useEffect, useState } from 'react';
import { Search, Heart, Trash2, Filter } from 'lucide-react';
import { getDownloads, deleteDownload, updateDownload } from '../lib/api';
import { useStore } from '../store/useStore';
import type { DownloadItem } from '../types';
import { Link } from 'react-router-dom';

export default function Library() {
  const { user, downloads, setDownloads } = useStore();
  const [search, setSearch] = useState('');
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    getDownloads({
      search: search || undefined,
      favorite: favoritesOnly ? '1' : undefined
    } as any)
      .then(setDownloads)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [user, search, favoritesOnly]);

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
        <p className="text-white/60">Connectez-vous pour voir votre bibliothèque</p>
        <Link to="/settings" className="text-primary-light text-sm font-medium">
          Aller aux paramètres →
        </Link>
      </div>
    );
  }

  const handleDelete = async (id: string) => {
    await deleteDownload(id);
    setDownloads(downloads.filter((d) => d.id !== id));
  };

  const toggleFav = async (item: DownloadItem) => {
    const next = item.is_favorite ? 0 : 1;
    await updateDownload(item.id, { is_favorite: next });
    setDownloads(downloads.map((d) => (d.id === item.id ? { ...d, is_favorite: next } : d)));
  };

  return (
    <div className="space-y-4 pt-2">
      <h1 className="text-xl font-bold">Bibliothèque</h1>

      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Rechercher..."
          className="w-full glass rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
        />
      </div>

      <div className="flex gap-2">
        <button
          onClick={() => setFavoritesOnly(!favoritesOnly)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition ${
            favoritesOnly ? 'bg-primary/30 text-primary-light' : 'glass text-white/60'
          }`}
        >
          <Heart size={12} /> Favoris
        </button>
        <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs glass text-white/60">
          <Filter size={12} /> Filtres
        </button>
      </div>

      {loading && <p className="text-sm text-white/40 text-center py-8">Chargement...</p>}

      {!loading && downloads.length === 0 && (
        <p className="text-sm text-white/40 text-center py-12">Aucun téléchargement</p>
      )}

      <div className="space-y-2">
        {downloads.map((item) => (
          <div key={item.id} className="glass rounded-2xl p-3 flex gap-3 items-center">
            {item.thumbnail ? (
              <img src={item.thumbnail} alt="" className="w-14 h-14 rounded-xl object-cover" />
            ) : (
              <div className="w-14 h-14 rounded-xl bg-surface-3" />
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{item.title}</p>
              <p className="text-[11px] text-white/40">
                {item.quality} · {item.format} · {item.status}
              </p>
            </div>
            <button onClick={() => toggleFav(item)} className="p-2">
              <Heart
                size={16}
                className={item.is_favorite ? 'fill-danger text-danger' : 'text-white/40'}
              />
            </button>
            <button onClick={() => handleDelete(item.id)} className="p-2 text-white/40 hover:text-danger">
              <Trash2 size={16} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
