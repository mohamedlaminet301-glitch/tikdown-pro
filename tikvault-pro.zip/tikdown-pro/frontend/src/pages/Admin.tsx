import { useEffect, useState } from 'react';
import { getAdminStats } from '../lib/api';
import { useStore } from '../store/useStore';
import { Link } from 'react-router-dom';

export default function Admin() {
  const user = useStore((s) => s.user);
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    if (user?.role === 'admin') {
      getAdminStats()
        .then(setStats)
        .catch(() => {});
    }
  }, [user]);

  if (!user || user.role !== 'admin') {
    return (
      <div className="text-center py-20 text-white/50">
        Accès réservé aux administrateurs
        <br />
        <Link to="/" className="text-primary-light text-sm">
          Retour
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6 pt-2">
      <h1 className="text-xl font-bold">Dashboard Admin</h1>

      {stats && (
        <div className="grid grid-cols-3 gap-3">
          <div className="glass rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-primary-light">{stats.users}</p>
            <p className="text-[11px] text-white/50">Utilisateurs</p>
          </div>
          <div className="glass rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-accent">{stats.downloads}</p>
            <p className="text-[11px] text-white/50">Téléchargements</p>
          </div>
          <div className="glass rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-success">{stats.completed}</p>
            <p className="text-[11px] text-white/50">Complétés</p>
          </div>
        </div>
      )}

      {stats?.recentUsers && (
        <section>
          <h2 className="text-sm font-semibold text-white/50 mb-2">Utilisateurs récents</h2>
          <div className="space-y-1">
            {stats.recentUsers.map((u: any) => (
              <div key={u.id} className="glass rounded-xl px-3 py-2 flex justify-between text-sm">
                <span>{u.username || u.email}</span>
                <span className="text-white/40 text-xs">{u.role}</span>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
