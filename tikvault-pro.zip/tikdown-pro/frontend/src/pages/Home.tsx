import { useState } from 'react';
import { Clock, Zap } from 'lucide-react';
import UrlInput from '../components/UrlInput';
import ResultCard from '../components/ResultCard';
import { analyzeUrl, createDownload } from '../lib/api';
import { useStore } from '../store/useStore';
import type { AnalyzeResult } from '../types';

export default function Home() {
  const {
    isAnalyzing,
    setAnalyzing,
    currentResult,
    setCurrentResult,
    addRecent,
    recentAnalyses,
    user
  } = useStore();
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async (url: string) => {
    setError(null);
    setAnalyzing(true);
    setCurrentResult(null);
    try {
      const data: AnalyzeResult = await analyzeUrl(url);
      setCurrentResult(data);
      addRecent(data);
    } catch (err: any) {
      setError(err.response?.data?.message || err.response?.data?.error || 'Échec de l\'analyse');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleDownload = async (source: AnalyzeResult['sources'][0]) => {
    if (!currentResult) return;
    // Direct browser download for the media URL
    const a = document.createElement('a');
    a.href = source.url;
    a.download = `${currentResult.title || 'video'}.${source.format === 'audio' ? 'mp3' : 'mp4'}`;
    a.target = '_blank';
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();

    // Also register in library if logged in
    if (user) {
      try {
        await createDownload({
          source_url: currentResult.url,
          title: currentResult.title,
          author: currentResult.author,
          thumbnail: currentResult.thumbnail,
          platform: currentResult.platform,
          type: currentResult.type,
          quality: source.quality,
          format: source.format,
          metadata: { download_url: source.url }
        });
      } catch (_) {}
    }
  };

  return (
    <div className="space-y-6 pt-2">
      <div className="text-center space-y-1">
        <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-white via-primary-light to-accent bg-clip-text text-transparent">
          Téléchargez sans filigrane
        </h1>
        <p className="text-sm text-white/50">TikTok · Qualité HD · PWA premium</p>
      </div>

      <UrlInput onAnalyze={handleAnalyze} loading={isAnalyzing} />

      {error && (
        <div className="rounded-2xl bg-danger/15 border border-danger/30 px-4 py-3 text-sm text-danger">
          {error}
        </div>
      )}

      {currentResult && (
        <ResultCard result={currentResult} onDownload={handleDownload} />
      )}

      {/* Quick actions */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => {
            const el = document.querySelector('input[type="url"]') as HTMLInputElement;
            el?.focus();
          }}
          className="glass rounded-2xl p-4 flex flex-col items-center gap-2 hover:bg-white/10 transition"
        >
          <Zap size={22} className="text-accent" />
          <span className="text-xs font-medium">Lien rapide</span>
        </button>
        <button
          className="glass rounded-2xl p-4 flex flex-col items-center gap-2 hover:bg-white/10 transition opacity-60"
          title="Bientôt disponible"
        >
          <Clock size={22} className="text-primary-light" />
          <span className="text-xs font-medium">Profil en lot</span>
        </button>
      </div>

      {/* Recent */}
      {recentAnalyses.length > 0 && (
        <section>
          <h2 className="text-sm font-semibold text-white/60 mb-3 flex items-center gap-2">
            <Clock size={14} /> Historique récent
          </h2>
          <div className="space-y-2">
            {recentAnalyses.slice(0, 5).map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentResult(item)}
                className="w-full glass rounded-xl p-3 flex gap-3 items-center text-left hover:bg-white/5 transition"
              >
                {item.thumbnail ? (
                  <img src={item.thumbnail} alt="" className="w-10 h-10 rounded-lg object-cover" />
                ) : (
                  <div className="w-10 h-10 rounded-lg bg-surface-3" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-sm truncate">{item.title}</p>
                  <p className="text-[11px] text-white/40 truncate">@{item.author}</p>
                </div>
              </button>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
