import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, AnalyzeResult, DownloadItem } from '../types';

interface AppState {
  user: User | null;
  token: string | null;
  recentAnalyses: AnalyzeResult[];
  downloads: DownloadItem[];
  queue: DownloadItem[];
  isAnalyzing: boolean;
  currentResult: AnalyzeResult | null;
  setAuth: (user: User | null, token: string | null) => void;
  logout: () => void;
  setAnalyzing: (v: boolean) => void;
  setCurrentResult: (r: AnalyzeResult | null) => void;
  addRecent: (r: AnalyzeResult) => void;
  setDownloads: (d: DownloadItem[]) => void;
  setQueue: (q: DownloadItem[]) => void;
  updateDownloadProgress: (id: string, progress: number, status?: string) => void;
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      recentAnalyses: [],
      downloads: [],
      queue: [],
      isAnalyzing: false,
      currentResult: null,
      setAuth: (user, token) => {
        if (token) localStorage.setItem('tikvault_token', token);
        else localStorage.removeItem('tikvault_token');
        set({ user, token });
      },
      logout: () => {
        localStorage.removeItem('tikvault_token');
        set({ user: null, token: null });
      },
      setAnalyzing: (v) => set({ isAnalyzing: v }),
      setCurrentResult: (r) => set({ currentResult: r }),
      addRecent: (r) =>
        set((s) => ({
          recentAnalyses: [r, ...s.recentAnalyses.filter((x) => x.url !== r.url)].slice(0, 12)
        })),
      setDownloads: (d) => set({ downloads: d }),
      setQueue: (q) => set({ queue: q }),
      updateDownloadProgress: (id, progress, status) =>
        set((s) => ({
          downloads: s.downloads.map((d) =>
            d.id === id ? { ...d, progress, status: (status as any) || d.status } : d
          ),
          queue: s.queue.map((d) =>
            d.id === id ? { ...d, progress, status: (status as any) || d.status } : d
          )
        }))
    }),
    {
      name: 'tikvault-storage',
      partialize: (s) => ({
        user: s.user,
        token: s.token,
        recentAnalyses: s.recentAnalyses
      })
    }
  )
);
