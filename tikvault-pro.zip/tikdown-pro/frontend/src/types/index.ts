export interface AnalyzeResult {
  id: string;
  url: string;
  platform: string;
  type: 'video' | 'photo' | 'slideshow';
  title: string;
  author: string;
  thumbnail: string | null;
  duration: number | null;
  sources: Array<{
    index: number;
    url: string;
    quality: string;
    format: string;
  }>;
}

export interface User {
  id: string;
  email: string;
  username: string;
  avatar_url?: string | null;
  role: string;
  preferences?: Record<string, unknown>;
}

export interface DownloadItem {
  id: string;
  user_id: string;
  source_url: string;
  platform: string;
  title: string;
  author: string | null;
  thumbnail: string | null;
  duration?: number | null;
  type: string;
  quality: string;
  format: string;
  status: 'pending' | 'queued' | 'downloading' | 'paused' | 'completed' | 'failed' | 'cancelled';
  progress: number;
  file_path?: string | null;
  file_size?: number | null;
  is_favorite: number;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface HistoryItem {
  id: string;
  source_url: string;
  platform: string;
  title: string;
  author: string | null;
  thumbnail: string | null;
  created_at: string;
}
