import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || '/api';

export const api = axios.create({
  baseURL: API_URL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('tikvault_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('tikvault_token');
      localStorage.removeItem('tikvault_user');
    }
    return Promise.reject(err);
  }
);

export async function analyzeUrl(url: string) {
  const { data } = await api.post('/analyze', { url });
  return data;
}

export async function login(email: string, password: string) {
  const { data } = await api.post('/auth/login', { email, password });
  return data;
}

export async function register(email: string, password: string, username?: string) {
  const { data } = await api.post('/auth/register', { email, password, username });
  return data;
}

export async function getMe() {
  const { data } = await api.get('/auth/me');
  return data;
}

export async function updateMe(payload: Record<string, unknown>) {
  const { data } = await api.patch('/auth/me', payload);
  return data;
}

export async function getDownloads(params?: Record<string, string>) {
  const { data } = await api.get('/downloads', { params });
  return data;
}

export async function createDownload(payload: Record<string, unknown>) {
  const { data } = await api.post('/downloads', payload);
  return data;
}

export async function updateDownload(id: string, payload: Record<string, unknown>) {
  const { data } = await api.patch(`/downloads/${id}`, payload);
  return data;
}

export async function deleteDownload(id: string) {
  await api.delete(`/downloads/${id}`);
}

export async function getHistory() {
  const { data } = await api.get('/history');
  return data;
}

export async function clearHistory() {
  await api.delete('/history');
}

export async function getQueue() {
  const { data } = await api.get('/downloads/queue/status');
  return data;
}

export async function getAdminStats() {
  const { data } = await api.get('/admin/stats');
  return data;
}
