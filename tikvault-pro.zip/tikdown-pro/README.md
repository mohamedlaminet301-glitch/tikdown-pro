# TikVault — Premium No-Watermark Video Downloader PWA

Application full-stack professionnelle pour analyser et télécharger des contenus vidéo (TikTok sans filigrane) avec une expérience mobile premium.

## Stack

| Couche | Technologies |
|--------|--------------|
| Frontend | React 18 + Vite + TypeScript + Tailwind CSS v4 + PWA + Framer Motion + Zustand |
| Backend | Node.js + Express + better-sqlite3 + JWT + Zod + Helmet + Rate limiting |
| Core downloader | SnapTik reverse-engineered client (inclus) |
| Auth | Email/password + structure Google OAuth |

## Structure

```
tikdown-pro/
├── frontend/          # PWA React
├── backend/           # API Express
│   ├── src/
│   │   ├── routes/
│   │   ├── services/snaptik.js
│   │   ├── middleware/
│   │   └── db/
│   └── data/          # SQLite DB
├── database/
├── documentation/
├── README.md
├── .env.example
└── package.json
```

## Installation

### Prérequis
- Node.js ≥ 18

### Backend
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```
API : http://localhost:3001

### Frontend
```bash
cd frontend
npm install
npm run dev
```
PWA : http://localhost:5173

Proxy Vite : `/api` → backend.

## Fonctionnalités

- Analyse lien TikTok (miniature, titre, auteur, sources HD/audio)
- Téléchargement direct + bibliothèque si connecté
- Historique récent
- Bibliothèque (recherche, favoris, suppression)
- Gestionnaire (file, progression, pause/reprise)
- Paramètres (qualité, format, Wi-Fi, notifications)
- PWA installable (manifest + service worker)
- Dashboard admin
- Sécurité : Zod, rate-limit, helmet, JWT

## Admin
```bash
sqlite3 backend/data/tikvault.db "UPDATE users SET role='admin' WHERE email='votre@email.com';"
```

## Notes
- SnapTik dépend de snaptik.app / dev.snaptik.app
- Profil batch : UI prête, extraction profil à étendre
- Google OAuth : structure prête

## Licence
MIT
