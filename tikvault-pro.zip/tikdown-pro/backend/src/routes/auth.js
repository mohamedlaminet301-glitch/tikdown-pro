const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { validate, loginSchema, registerSchema } = require('../middleware/validate');
const { authRequired } = require('../middleware/auth');
const db = require('../db');

const router = express.Router();

function signToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role, username: user.username },
    process.env.JWT_SECRET || 'dev-secret',
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

router.post('/register', validate(registerSchema), async (req, res) => {
  const { email, password, username } = req.validated.body;
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    return res.status(409).json({ error: 'Email already registered' });
  }

  const id = uuidv4();
  const hash = await bcrypt.hash(password, 12);
  const name = username || email.split('@')[0];

  db.prepare(
    `INSERT INTO users (id, email, password_hash, username, role) VALUES (?, ?, ?, ?, ?)`
  ).run(id, email, hash, name, 'user');

  const user = { id, email, username: name, role: 'user' };
  const token = signToken(user);
  res.status(201).json({ user, token });
});

router.post('/login', validate(loginSchema), async (req, res) => {
  const { email, password } = req.validated.body;
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!row) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const ok = await bcrypt.compare(password, row.password_hash);
  if (!ok) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const user = {
    id: row.id,
    email: row.email,
    username: row.username,
    avatar_url: row.avatar_url,
    role: row.role,
    preferences: JSON.parse(row.preferences || '{}')
  };
  const token = signToken(user);
  res.json({ user, token });
});

router.get('/me', authRequired, (req, res) => {
  const row = db.prepare('SELECT id, email, username, avatar_url, role, preferences, created_at FROM users WHERE id = ?').get(req.user.id);
  if (!row) return res.status(404).json({ error: 'User not found' });
  res.json({
    ...row,
    preferences: JSON.parse(row.preferences || '{}')
  });
});

router.patch('/me', authRequired, (req, res) => {
  const { username, avatar_url, preferences } = req.body;
  const updates = [];
  const values = [];

  if (username !== undefined) {
    updates.push('username = ?');
    values.push(username);
  }
  if (avatar_url !== undefined) {
    updates.push('avatar_url = ?');
    values.push(avatar_url);
  }
  if (preferences !== undefined) {
    updates.push('preferences = ?');
    values.push(JSON.stringify(preferences));
  }

  if (updates.length === 0) {
    return res.status(400).json({ error: 'No fields to update' });
  }

  updates.push("updated_at = datetime('now')");
  values.push(req.user.id);

  db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...values);
  const row = db.prepare('SELECT id, email, username, avatar_url, role, preferences FROM users WHERE id = ?').get(req.user.id);
  res.json({ ...row, preferences: JSON.parse(row.preferences || '{}') });
});

// Google OAuth placeholder structure
router.get('/google', (req, res) => {
  res.status(501).json({
    error: 'Google OAuth not configured',
    message: 'Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET, then implement the flow.'
  });
});

module.exports = router;
