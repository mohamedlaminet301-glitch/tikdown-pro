const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { authRequired, authOptional } = require('../middleware/auth');
const db = require('../db');

const router = express.Router();

// List user downloads / library
router.get('/', authRequired, (req, res) => {
  const { search, favorite, status, sort = 'created_at', order = 'desc' } = req.query;
  let sql = 'SELECT * FROM downloads WHERE user_id = ?';
  const params = [req.user.id];

  if (search) {
    sql += ' AND (title LIKE ? OR author LIKE ? OR source_url LIKE ?)';
    const q = `%${search}%`;
    params.push(q, q, q);
  }
  if (favorite === '1' || favorite === 'true') {
    sql += ' AND is_favorite = 1';
  }
  if (status) {
    sql += ' AND status = ?';
    params.push(status);
  }

  const allowedSort = ['created_at', 'title', 'progress', 'updated_at'];
  const s = allowedSort.includes(sort) ? sort : 'created_at';
  const o = order.toLowerCase() === 'asc' ? 'ASC' : 'DESC';
  sql += ` ORDER BY ${s} ${o} LIMIT 200`;

  const rows = db.prepare(sql).all(...params);
  res.json(rows.map((r) => ({ ...r, metadata: JSON.parse(r.metadata || '{}') })));
});

// Create download entry (queue)
router.post('/', authRequired, (req, res) => {
  const { source_url, title, author, thumbnail, platform, type, quality, format, metadata } = req.body;
  if (!source_url) return res.status(400).json({ error: 'source_url required' });

  const id = uuidv4();
  db.prepare(
    `INSERT INTO downloads (id, user_id, source_url, platform, title, author, thumbnail, type, quality, format, status, metadata)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'queued', ?)`
  ).run(
    id,
    req.user.id,
    source_url,
    platform || 'tiktok',
    title || 'Untitled',
    author || null,
    thumbnail || null,
    type || 'video',
    quality || 'hd',
    format || 'mp4',
    JSON.stringify(metadata || {})
  );

  // Add to queue
  const pos = db.prepare('SELECT COALESCE(MAX(position), 0) + 1 as p FROM download_queue WHERE user_id = ?').get(req.user.id).p;
  db.prepare(
    `INSERT INTO download_queue (id, user_id, download_id, position, status) VALUES (?, ?, ?, ?, 'queued')`
  ).run(uuidv4(), req.user.id, id, pos);

  const row = db.prepare('SELECT * FROM downloads WHERE id = ?').get(id);
  res.status(201).json({ ...row, metadata: JSON.parse(row.metadata || '{}') });
});

// Update progress / status
router.patch('/:id', authRequired, (req, res) => {
  const { status, progress, file_path, file_size, is_favorite } = req.body;
  const row = db.prepare('SELECT * FROM downloads WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!row) return res.status(404).json({ error: 'Not found' });

  const updates = [];
  const values = [];
  if (status !== undefined) { updates.push('status = ?'); values.push(status); }
  if (progress !== undefined) { updates.push('progress = ?'); values.push(progress); }
  if (file_path !== undefined) { updates.push('file_path = ?'); values.push(file_path); }
  if (file_size !== undefined) { updates.push('file_size = ?'); values.push(file_size); }
  if (is_favorite !== undefined) { updates.push('is_favorite = ?'); values.push(is_favorite ? 1 : 0); }
  updates.push("updated_at = datetime('now')");
  values.push(req.params.id);

  db.prepare(`UPDATE downloads SET ${updates.join(', ')} WHERE id = ?`).run(...values);
  const updated = db.prepare('SELECT * FROM downloads WHERE id = ?').get(req.params.id);
  res.json({ ...updated, metadata: JSON.parse(updated.metadata || '{}') });
});

router.delete('/:id', authRequired, (req, res) => {
  const result = db.prepare('DELETE FROM downloads WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  if (result.changes === 0) return res.status(404).json({ error: 'Not found' });
  db.prepare('DELETE FROM download_queue WHERE download_id = ?').run(req.params.id);
  res.status(204).send();
});

// Queue status
router.get('/queue/status', authRequired, (req, res) => {
  const queue = db.prepare(
    `SELECT q.*, d.title, d.progress, d.status as download_status, d.thumbnail
     FROM download_queue q
     JOIN downloads d ON d.id = q.download_id
     WHERE q.user_id = ?
     ORDER BY q.position ASC`
  ).all(req.user.id);
  res.json(queue);
});

module.exports = router;
