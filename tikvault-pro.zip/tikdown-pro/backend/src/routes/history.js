const express = require('express');
const { authRequired } = require('../middleware/auth');
const db = require('../db');

const router = express.Router();

router.get('/', authRequired, (req, res) => {
  const rows = db.prepare(
    `SELECT * FROM history WHERE user_id = ? ORDER BY created_at DESC LIMIT 50`
  ).all(req.user.id);
  res.json(rows);
});

router.delete('/', authRequired, (req, res) => {
  db.prepare('DELETE FROM history WHERE user_id = ?').run(req.user.id);
  res.status(204).send();
});

module.exports = router;
