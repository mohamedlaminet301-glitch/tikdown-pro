const express = require('express');
const { adminRequired } = require('../middleware/auth');
const db = require('../db');

const router = express.Router();

router.use(adminRequired);

router.get('/stats', (req, res) => {
  const users = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
  const downloads = db.prepare('SELECT COUNT(*) as count FROM downloads').get().count;
  const completed = db.prepare("SELECT COUNT(*) as count FROM downloads WHERE status = 'completed'").get().count;
  const recent = db.prepare(
    `SELECT id, email, username, role, created_at FROM users ORDER BY created_at DESC LIMIT 10`
  ).all();

  res.json({
    users,
    downloads,
    completed,
    recentUsers: recent
  });
});

router.get('/users', (req, res) => {
  const rows = db.prepare(
    `SELECT id, email, username, role, created_at FROM users ORDER BY created_at DESC LIMIT 100`
  ).all();
  res.json(rows);
});

router.get('/logs', (req, res) => {
  // Placeholder: real logs would come from a logger table or files
  res.json({
    message: 'Log aggregation not implemented. Use server stdout or a proper logger (winston/pino).'
  });
});

module.exports = router;
