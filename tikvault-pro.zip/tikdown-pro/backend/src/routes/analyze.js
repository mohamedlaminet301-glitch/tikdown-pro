const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { SnapTikClient } = require('../services/snaptik');
const { detectPlatform, isSupported } = require('../utils/platform');
const { validate, analyzeSchema } = require('../middleware/validate');
const { authOptional } = require('../middleware/auth');
const db = require('../db');

const router = express.Router();
const client = new SnapTikClient();

router.post('/', authOptional, validate(analyzeSchema), async (req, res) => {
  const { url } = req.validated.body;
  const platform = detectPlatform(url);

  if (!isSupported(platform)) {
    return res.status(400).json({
      error: 'Platform not supported yet',
      platform,
      supported: ['tiktok']
    });
  }

  try {
    const result = await client.process(url);

    // Enrich with basic metadata from oembed if available
    let title = null;
    let author = null;
    let thumbnail = null;
    let duration = null;

    if (result.oembed_url) {
      try {
        const oembedRes = await require('axios').get(result.oembed_url, { timeout: 5000 });
        const o = oembedRes.data;
        title = o.title || null;
        author = o.author_name || null;
        thumbnail = o.thumbnail_url || null;
      } catch (_) {}
    }

    // Fallback thumbnail from first source if image
    const sources = result.data?.sources || [];
    const sourceUrls = sources.map((s) => (typeof s === 'string' ? s : s.url)).filter(Boolean);

    const payload = {
      id: uuidv4(),
      url,
      platform,
      type: result.type || 'video',
      title: title || 'TikTok Video',
      author: author || 'Unknown',
      thumbnail,
      duration,
      sources: sourceUrls.map((u, i) => ({
        index: i,
        url: u,
        quality: i === 0 ? 'hd' : i === 1 ? 'standard' : 'other',
        format: u.includes('.mp3') || u.includes('audio') ? 'audio' : 'video'
      })),
      raw: result
    };

    // Save to history if authenticated
    if (req.user?.id) {
      try {
        db.prepare(
          `INSERT INTO history (id, user_id, source_url, platform, title, author, thumbnail)
           VALUES (?, ?, ?, ?, ?, ?, ?)`
        ).run(uuidv4(), req.user.id, url, platform, payload.title, payload.author, thumbnail);
      } catch (_) {}
    }

    res.json(payload);
  } catch (err) {
    console.error('Analyze error:', err.message);
    res.status(502).json({
      error: 'Failed to analyze URL',
      message: err.message || 'SnapTik service unavailable or invalid link'
    });
  }
});

module.exports = router;
