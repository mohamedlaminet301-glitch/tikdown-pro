/**
 * SnapTik reverse-engineered client (adapted from snaptik-app-api)
 * Provides no-watermark TikTok video/photo extraction.
 */
const axios = require('axios');
const cheerio = require('cheerio');
const FormData = require('form-data');

class Resource {
  constructor(url, index) {
    this.index = index;
    this.url = url;
  }

  download(config = {}) {
    return axios({
      url: this.url,
      responseType: 'stream',
      ...config
    });
  }
}

class SnapTikClient {
  constructor(config = {}) {
    this.config = {
      baseURL: process.env.SNAPTIK_BASE_URL || 'https://dev.snaptik.app',
      ...config
    };
    this.axios = axios.create(this.config);
  }

  async get_token() {
    const { data } = await this.axios({ url: '/' });
    const $ = cheerio.load(data);
    return $('input[name="token"]').val();
  }

  async get_script(url) {
    const form = new FormData();
    const token = await this.get_token();
    form.append('token', token);
    form.append('url', url);

    const { data } = await this.axios({
      url: '/abc2.php',
      method: 'POST',
      data: form
    });
    return data;
  }

  async eval_script(script1) {
    const script2 = await new Promise((resolve) => Function('eval', script1)(resolve));
    return new Promise((resolve, reject) => {
      let html = '';
      const mocks = {
        $: () =>
          Object.defineProperty(
            {
              remove() {},
              style: { display: '' }
            },
            'innerHTML',
            { set: (t) => (html = t) }
          ),
        app: { showAlert: reject },
        document: { getElementById: () => ({ src: '' }) },
        fetch: (a) => {
          resolve({ html, oembed_url: a });
          return { json: () => ({ thumbnail_url: '' }) };
        },
        gtag: () => 0,
        Math: { round: () => 0 },
        XMLHttpRequest: function () {
          return { open() {}, send() {} };
        },
        window: { location: { hostname: 'snaptik.app' } }
      };
      const k = Object.keys(mocks);
      const v = Object.values(mocks);
      Function(...k, script2)(...v);
    });
  }

  async get_hd_video(token) {
    const {
      data: { error, url }
    } = await this.axios({ url: '/getHdLink.php?token=' + token });
    if (error) throw new Error(error);
    return url;
  }

  async parse_html(html) {
    const $ = cheerio.load(html);
    const is_video = !$('div.render-wrapper').length;

    if (is_video) {
      const hd_token = $('div.video-links > button[data-tokenhd]').data('tokenhd');
      let sources = [];

      if (hd_token) {
        try {
          const hd_url = new URL(await this.get_hd_video(hd_token));
          const token = hd_url.searchParams.get('token');
          if (token) {
            const payload = JSON.parse(
              Buffer.from(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString()
            );
            if (payload.url) sources.push(payload.url);
          }
          sources.push(hd_url.href);
        } catch (e) {
          // HD may fail; continue with standard links
        }
      }

      const links = $('div.video-links > a:not(a[href="/"])')
        .toArray()
        .map((elem) => $(elem).attr('href'))
        .map((x) => (x && x.startsWith('/') ? this.config.baseURL + x : x))
        .filter(Boolean);

      sources = [...sources, ...links];
      sources = [...new Set(sources)]; // unique

      return {
        type: 'video',
        data: {
          sources: sources.map((url, i) => new Resource(url, i))
        }
      };
    }

    // Slideshow / photos
    const photos = $('div.columns > div.column > div.photo')
      .toArray()
      .map((elem) => ({
        sources: [
          $(elem).find('img[alt="Photo"]').attr('src'),
          $(elem).find('a[data-event="download_albumPhoto_photo"]').attr('href')
        ]
          .filter(Boolean)
          .map((url, i) => new Resource(url, i))
      }));

    if (photos.length === 1) {
      return {
        type: 'photo',
        data: { sources: photos[0].sources }
      };
    }

    return {
      type: 'slideshow',
      data: { photos }
    };
  }

  async process(url) {
    const script = await this.get_script(url);
    const { html, oembed_url } = await this.eval_script(script);
    const parsed = await this.parse_html(html);

    return {
      ...parsed,
      url,
      oembed_url
    };
  }
}

module.exports = { SnapTikClient, Resource };
