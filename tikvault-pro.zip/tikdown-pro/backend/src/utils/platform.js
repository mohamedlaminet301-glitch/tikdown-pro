/**
 * Detect platform from URL
 */
function detectPlatform(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    if (host.includes('tiktok.com') || host.includes('vm.tiktok.com') || host.includes('vt.tiktok.com')) {
      return 'tiktok';
    }
    if (host.includes('instagram.com') || host.includes('instagr.am')) return 'instagram';
    if (host.includes('youtube.com') || host.includes('youtu.be')) return 'youtube';
    if (host.includes('twitter.com') || host.includes('x.com')) return 'twitter';
    if (host.includes('facebook.com') || host.includes('fb.watch')) return 'facebook';
    return 'unknown';
  } catch {
    return 'unknown';
  }
}

function isSupported(platform) {
  // Currently full support only for TikTok via SnapTik
  return platform === 'tiktok';
}

module.exports = { detectPlatform, isSupported };
