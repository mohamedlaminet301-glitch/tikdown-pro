const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dbPath = process.env.DATABASE_PATH || path.join(__dirname, '../../data/tikvault.db');
const dir = path.dirname(dbPath);
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

const db = new Database(dbPath);

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT,
    username TEXT,
    avatar_url TEXT,
    role TEXT DEFAULT 'user',
    preferences TEXT DEFAULT '{}',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS downloads (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    source_url TEXT NOT NULL,
    platform TEXT,
    title TEXT,
    author TEXT,
    thumbnail TEXT,
    duration INTEGER,
    type TEXT,
    quality TEXT,
    format TEXT,
    status TEXT DEFAULT 'pending',
    progress REAL DEFAULT 0,
    file_path TEXT,
    file_size INTEGER,
    is_favorite INTEGER DEFAULT 0,
    metadata TEXT DEFAULT '{}',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS history (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    source_url TEXT NOT NULL,
    platform TEXT,
    title TEXT,
    author TEXT,
    thumbnail TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS download_queue (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    download_id TEXT,
    position INTEGER,
    status TEXT DEFAULT 'queued',
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (download_id) REFERENCES downloads(id)
  );

  CREATE INDEX IF NOT EXISTS idx_downloads_user ON downloads(user_id);
  CREATE INDEX IF NOT EXISTS idx_history_user ON history(user_id);
  CREATE INDEX IF NOT EXISTS idx_queue_user ON download_queue(user_id);
`);

console.log('Database initialized at', dbPath);
db.close();
