# Architecture TikVault

Frontend (React PWA) <-> REST API (Express) <-> SnapTik + SQLite

Flux analyse : POST /api/analyze -> SnapTikClient.process -> oEmbed enrich -> JSON sources.

Auth JWT Bearer. Rôles user/admin. PWA via vite-plugin-pwa.
