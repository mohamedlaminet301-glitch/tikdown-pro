# API

GET /api/health
POST /api/analyze { url }
POST /api/auth/register | login
GET|PATCH /api/auth/me
GET|POST|PATCH|DELETE /api/downloads
GET /api/downloads/queue/status
GET|DELETE /api/history
GET /api/admin/stats (admin)
