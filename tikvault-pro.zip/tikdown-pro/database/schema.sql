-- TikVault SQLite schema (auto-applied by backend)
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT,
  username TEXT,
  avatar_url TEXT,
  role TEXT DEFAULT 'user',
  preferences TEXT DEFAULT '{}',
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS downloads (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  source_url TEXT NOT NULL,
  platform TEXT,
  title TEXT,
  author TEXT,
  thumbnail TEXT,
  duration INTEGER,
  type TEXT,
  quality TEXT,
  format TEXT,
  status TEXT DEFAULT 'pending',
  progress REAL DEFAULT 0,
  file_path TEXT,
  file_size INTEGER,
  is_favorite INTEGER DEFAULT 0,
  metadata TEXT DEFAULT '{}',
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS history (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  source_url TEXT NOT NULL,
  platform TEXT,
  title TEXT,
  author TEXT,
  thumbnail TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS download_queue (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  download_id TEXT,
  position INTEGER,
  status TEXT DEFAULT 'queued',
  created_at TEXT DEFAULT (datetime('now'))
);
